package com.rainty.sample.starter.entity;

import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2015-01-13T08:39:31.536+0800")
@StaticMetamodel(AssetType.class)
public class AssetType_ {
	public static volatile SingularAttribute<AssetType, String> assetType;
	public static volatile SingularAttribute<AssetType, String> typeDescription;
	public static volatile SingularAttribute<AssetType, Timestamp> updateDt;
	public static volatile SingularAttribute<AssetType, String> updateUser;
}
